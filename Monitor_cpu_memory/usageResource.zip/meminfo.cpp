#include "meminfo.h"

MemInfo::MemInfo()
{

}
