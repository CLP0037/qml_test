#ifndef MEMINFO_H
#define MEMINFO_H

#include "generalinfo.h"

class MemInfo: public GeneralInfo
{
public:
    MemInfo();
};

#endif // MEMINFO_H
