#include "sysinfo.h"

SysInfo::SysInfo()
{

}
