#ifndef CPUINFO_H
#define CPUINFO_H

#include "generalinfo.h"

class CpuInfo : public GeneralInfo
{
public:
    CpuInfo();
};

#endif // CPUINFO_H
