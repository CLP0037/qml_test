#include "cpuinfo.h"

CpuInfo::CpuInfo()
{

}
